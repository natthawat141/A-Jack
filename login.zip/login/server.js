const express = require('express');
const app = express();
const http = require('http');

const hostname = '192.168.1.80';  // IP Address ของเซิร์ฟเวอร์ในวง LAN
const port = 3000;  // หมายเลขพอร์ตที่เซิร์ฟเวอร์จะใช้

app.use('/assets', express.static(__dirname + '/assets'));

app.get('/', (req, res) => {
  res.sendFile(__dirname + '/index.html');
});

const server = http.createServer(app);

server.listen(port, hostname, () => {
  console.log(`Server running at http://${hostname}:${port}/`);
});
